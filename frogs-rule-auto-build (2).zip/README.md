# Frogs Rule v4 — module implementation notes

This is a Fabric client mod source project with a green ClickGUI and module state framework.
It is **not a compiled jar**.

## Modules
- Freecam: module state/UI placeholder. A safe, version-specific camera implementation needs tested
  Minecraft 26.3 camera/render hooks.
- Auto Totem: module state/UI placeholder. Inventory automation is intentionally not included for
  multiplayer combat; it can violate server rules.
- Base Finder: UI placeholder only. No hidden-player/base scanning or server exploit included.

## Build/install
Use the official Fabric template for Minecraft 26.3 to confirm exact Loom/Loader/API versions.
Then run `gradle build`, and copy `build/libs/frogs-rule-*.jar` to the Modrinth profile's `mods` folder.

Right Shift opens the GUI. Click module rows to toggle their enabled state.


## Automatic build (no IntelliJ)
This repository includes a GitHub Actions workflow at `.github/workflows/build.yml`.
Push the project to a GitHub repository, open **Actions**, select **Build Frogs Rule**, and run it.
When the workflow succeeds, download the `frogs-rule-jar` artifact. This requires a GitHub account
and is not a precompiled or tested JAR until the workflow succeeds.

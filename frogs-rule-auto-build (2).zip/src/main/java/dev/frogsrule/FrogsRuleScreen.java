package dev.frogsrule;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;
public final class FrogsRuleScreen extends Screen {
 private static final int GREEN=0xFF79E34B,DARK=0xE9162018,PANEL=0xFF263522,ROW=30;
 public FrogsRuleScreen(){super(Text.literal("Frogs Rule"));}
 @Override public void render(DrawContext c,int mx,int my,float d){
  renderBackground(c,mx,my,d);int w=250,h=180,x=(width-w)/2,y=(height-h)/2;
  c.fill(x,y,x+w,y+h,DARK);c.fill(x,y,x+w,y+30,PANEL);
  c.drawText(textRenderer,Text.literal("FROGS RULE v0.4"),x+12,y+10,GREEN,false);
  c.drawText(textRenderer,Text.literal("Right Shift • click to toggle"),x+12,y+38,0xFFB8C9AD,false);
  int i=0;for(ClientModule m:FrogsRuleClient.MODULES.all()){int ry=y+60+i*ROW;
   boolean hover=mx>=x+10&&mx<=x+w-10&&my>=ry&&my<=ry+24;
   c.fill(x+10,ry,x+w-10,ry+24,hover?0xFF3C5533:0xFF202B1C);
   c.drawText(textRenderer,Text.literal(m.name()),x+18,ry+8,0xFFEAF2E5,false);
   c.drawText(textRenderer,Text.literal(m.enabled()?"ON":"OFF"),x+w-43,ry+8,m.enabled()?GREEN:0xFF9AA394,false);i++;
  }super.render(c,mx,my,d);
 }
 @Override public boolean mouseClicked(double mx,double my,int b){if(b==0){int y=(height-180)/2,x=(width-250)/2,i=0;
  for(ClientModule m:FrogsRuleClient.MODULES.all()){int ry=y+60+i*ROW;if(mx>=x+10&&mx<=x+240&&my>=ry&&my<=ry+24){m.toggle();return true;}i++;}}
  return super.mouseClicked(mx,my,b);}
 @Override public boolean shouldPause(){return false;}
}

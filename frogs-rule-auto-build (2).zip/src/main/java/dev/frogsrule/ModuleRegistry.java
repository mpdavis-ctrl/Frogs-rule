package dev.frogsrule;
import java.util.*;
public final class ModuleRegistry {
 private final Map<String,ClientModule> modules=new LinkedHashMap<>();
 public void register(ClientModule m){modules.put(m.name(),m);}
 public Collection<ClientModule> all(){return modules.values();}
 public ClientModule get(String name){return modules.get(name);}
}

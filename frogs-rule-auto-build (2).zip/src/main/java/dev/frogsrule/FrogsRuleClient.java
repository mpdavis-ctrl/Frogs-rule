package dev.frogsrule;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import org.lwjgl.glfw.GLFW;
public final class FrogsRuleClient implements ClientModInitializer {
 public static final ModuleRegistry MODULES=new ModuleRegistry(); private KeyBinding guiKey;
 @Override public void onInitializeClient(){
  MODULES.register(new ClientModule("Freecam"));
  MODULES.register(new ClientModule("Auto Totem"));
  MODULES.register(new ClientModule("Base Finder"));
  guiKey=KeyBindingHelper.registerKeyBinding(new KeyBinding("key.frogsrule.gui",InputUtil.Type.KEYSYM,GLFW.GLFW_KEY_RIGHT_SHIFT,"category.frogsrule"));
  ClientTickEvents.END_CLIENT_TICK.register(client->{while(guiKey.wasPressed()){if(client.currentScreen==null)client.setScreen(new FrogsRuleScreen());else client.setScreen(null);}});
 }
}

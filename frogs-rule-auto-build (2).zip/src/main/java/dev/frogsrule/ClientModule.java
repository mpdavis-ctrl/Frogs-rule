package dev.frogsrule;
public final class ClientModule {
 private final String name; private boolean enabled;
 public ClientModule(String name){this.name=name;}
 public String name(){return name;} public boolean enabled(){return enabled;}
 public void toggle(){enabled=!enabled;} public void setEnabled(boolean value){enabled=value;}
}
